
<style>
    body{
        color:black;
    }
    h1{
        text-align: center;    
    }
</style>
<?php
    $usuario = $_POST['login'];
    $senha = $_POST['senha'];
    include_once("config.php");
    $conexao = conectar();
    $sql = "SELECT * FROM tb_usuario WHERE login_user LIKE '%$usuario%' AND senha_user LIKE '$senha';";
    $pesquisa= mysqli_query($conexao,$sql);

    if(mysqli_num_rows($pesquisa)>0){

        while($resu=mysqli_fetch_assoc($pesquisa)){
            echo "<br><br><br>>";
            echo "<h1>BEM VINDO A TURMA 252 ".$usuario."</h1>";
        }
    }else{
        echo "<br><br><br><br>";
        echo "<h1>NENHUM USUÁRIO ENCONTRADO</h1>";
    }
?>
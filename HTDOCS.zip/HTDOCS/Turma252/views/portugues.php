<br><br><br><br><br><br>
<h1 align=center style="color:darkred; font-weight:bold; font-style:italic; -webkit-text-stroke-width: 2px;   -webkit-text-stroke-color: black;">PORTUGUÊS</h1>
<br><br><br><br><br><br>
<style>
    .maumau{
        max-width: 600px;
        position: absolute;
        top: 40%;
        left: 50%;
        transform: translate(-50%,-50%);
    }

</style>
<div class="maumau">
    <form action="?pagina=confirmar_login" method="POST">
        <h1 class="h3 mb-3 fw-normal">LOGAR</h1>
            <div class="form-floating">
            <label for="floatingInput">Digite Login</label>
            <input type="text" class="form-control" name="login" id="username" placeholder="Digite Usuário" required>
            </div>
            <div class="form-floating">
            <label for="floatingPassword">Password</label>
            <input type="password" class="form-control" name="senha" id="inputPassword" placeholder="Password" required>
            </div>
            <br>
            <button class="btn btn-primary w-100 py-2" type="submit">Clique Aqui</button>
            <h6>Não possui conta? <a href="?pagina=cadastrar">Clique aqui</a></h6>
    </form>
</div>
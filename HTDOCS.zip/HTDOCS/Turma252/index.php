<!DOCTYPE html>
    <html lang="pt-br">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
            <title>TURMA 2-52</title>
            <style>
                .higor{
                    font-size: 18px;
                    font-weight: bold;
                    color:white !important;
                    font-style: italic;
                }
                body{
                    background-image: url(img/BACKGROUND3.gif);
                    background-repeat: no-repeat;
                    background-size: cover;
                    background-position-y: -12%;
                }
                .logo{
                    background-repeat: no-repeat;
                    background-size: cover;
                    max-width: 110px;
                    max-height: 110px;
                }
                .HOME.png{
                   background-image: url(img/HOME.png);
                   background-repeat: no-repeat;
                   background-size: cover;
                   max-width: 110px;
                   max-height: 110px;
                }
            
                
                
            </style>
        </head>
        <body>
    <!--nav class="navbar navbar-expand-lg navbar-dark bg-info fixed-top"-->
            <nav class="navbar navbar-expand-lg navbar-dark fixed-top " style="background-color:darkmagenta;" >
        
                <a class="navbar-brand" href="?pagina=home"><img src="img/LOGO3.gif" class="logo"><img src="img/2-52.png"></a>

        <!--BOTAO DO HIGOR-->
                <button class="navbar-toggler" type="button" data-toggle="collapse"
                aria-controls="navbarNavDropdown" aria-expanded="false" data-target="#Higor">
                <span class="navbar-toggler-icon"></span>
                </button>

                    <div class="collapse navbar-collapse d-lg-flex justify-content-end" id="Higor">
                        <ul class="navbar-nav">
                            <li class="nav-item mr-2 ml-3">
                                <a class="nav-link higor" href="?pagina=home"><img src="img/HOME.png"><span class="sr-only"></span></a>
                            </li>

                            <li class="nav-item mr-2 ml-3">
                                <a class="nav-link higor" href="?pagina=download"><img src="img/DOWNLOADS.png"><span class="sr-only"></span></a>
                            </li>

                            <li class="nav-item mr-2 ml-3">
                                <a class="nav-link higor" href="?pagina=envio"><img src="img/ENVIO.png"><span class="sr-only"></span></a>
                            </li>

                            <li class="nav-item dropdown mr-2 ml-3">
                                <a class="nav-link higor" href="#" dropdown-toggle
                                id="NavBarDrop" role="button" data-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false">
                                <img src="img/DISCIPLINAS.png"><span class="sr-only"></span></a>
                                <div class="dropdown-menu" aria-labelledby="NavBarDrop">
                                    <a class="dropdown-item" href="?pagina=matematica">Matemática</a>
                                    <a class="dropdown-item" href="?pagina=portugues">Português</a>
                                    <a class="dropdown-item" href="?pagina=historia">História</a>
                        
                                </div>
                            </li>
                            <li class="nav-item mr-2 ml-3">
                                <a class="nav-link higor" href="?pagina=login"><img src="img/LOGAR.png"><span class="sr-only"></span></a>
                            </li>
                        </ul>
                    </div>
            </nav>
            <?php
                if(!isset($_GET['pagina'])){
                    include("views/home.php");
                }else{
                    $link = $_GET['pagina'];
                    switch($link){
                        case "download";
                        include("views/downloads.php");
                    break;
                        case "home";
                        include("views/home.php");
                    break;
                        case "envio";
                        include("views/envio.php");
                    break;
                        case "matematica";
                        include("views/matematica.php");
                    break;
                        case "portugues";
                        include("views/portugues.php");
                    break;
                        case "historia";
                        include("views/historia.php");
                    break;
                        case "higor";
                        include("views/higor.php");
                    break;
                        case "bluezao";
                        include("views/bluezao.php");
                    break;
                        case "warmling";
                        include("views/warmling.php");
                    break;
                        case "login";
                        include("views/login.php");
                    break;
                        case "cadastrar";
                        include("views/cadastro.php");
                    break;
                        case "confirmar_cadastro";
                        include("cadastrar.php");
                    break;
                        case "confirmar_login";
                        include("logar.php");
                    break;
                    }
                }

            ?>
        </body>

    <script src="bootstrap/js/jquery.js"></script>
    <script src="bootstrap/js/popper.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>

    </html>
<?php
    $nome = $_POST['nome'];
    $login = $_POST['login'];
    $senha = $_POST['senha'];
    include_once("config.php");

    $sql="INSERT INTO tb_usuario(nome_user,login_user,senha_user) VALUES('$nome','$login','$senha');";
    $conexao = conectar();
    if(mysqli_query($conexao, $sql)){
        echo "<br><br><br><br><br>";
        echo "<h3 align=center>REGISTRADO COM SUCESSO</h3>";
        echo "<h3 align=center><a href='?pagina=cadastrar'>Novo Cadastro</a></h3>";
        echo "<h3 align=center><a href='?pagina=home'>Voltar a Home</a></h3>";
    }else{
        echo "<br><br><br><br><br>";
        echo "<h3 align=center>ERRO NO REGISTRO".mysqli_connect_error()."</h3>";
    }
?>
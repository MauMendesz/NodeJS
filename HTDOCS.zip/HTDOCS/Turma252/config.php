<?php
    function conectar(){
        $servidor = "localhost";
        $user = "root";
        $passwd = "";
        $bancodados = "Exercicio_avalia";
        @$conexao = mysqli_connect($servidor, $user, $passwd, $bancodados);
        return $conexao;
    }
?>
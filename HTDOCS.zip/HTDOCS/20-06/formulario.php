<?php
  include_once("conexao.php"); 

  $id = isset($_GET['id']) ? $_GET['id'] : 0;  

  $nome = '';
  $data = '';
  $descricao = '';

  $sql = "SELECT * FROM tarefas WHERE id = $id;";
  $query = mysqli_query($conn,$sql);

  while($row = mysqli_fetch_assoc($query)){
    $nome  = $row['nome'];
    $data  = $row['data'];
    $descricao = $row['descricao'];
  }
?>

<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <link rel="stylesheet" href="style.css">
  </head>
<center>
<body> 
  <div>    
    <form action="atualizarUsuario.php" method="POST">
      <input type="hidden" id="id" name="id" value="<?=$id?>"/>
      <br><br><br><br>
      <h1>EDIÇÃO<br>DE TAREFA</h1><br>
      <label>Nome Tarefa<br>
        <input placeholder="Digite seu Login" type="text" name="nomeTarefa" value="<?=$nome?>" required>
      </label><br><br>
      <label>Data de Entrega<br>
        <input type="date"  name="data" value="<?=$data?>" required>
      </label><br><br>
      <label>Descrição Tarefa<br>
        <input placeholder="Digite a Descrição" type="text" name="descricao" value="<?=$descricao?>" size="40" required>
      </label><br><br>
        <br>
      <a><button  type="submit">ENVIAR</button></>
      <a href="lista.php"><button type="button">VOLTAR</button></a>
    </form>
  </div>
</body>
</center>
</html>
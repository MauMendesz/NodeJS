<?php

    include('conexao.php');


    $login = $_POST['login'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    $senhaEncriptada = password_hash($senha, PASSWORD_BCRYPT);


    $sqlInsert = $conn->prepare("INSERT INTO autenticacao (login, email, senha) VALUES (?, ?, ?)");
    $sqlInsert->bind_param('sss', $login, $email, $senhaEncriptada);

    if ($sqlInsert->execute()) {
        echo "
        <center>
        <b><h1>Novo Registro<br>criado com sucesso!</h1></b>
        <a href='index.php'><button>Voltar</button></a>
        </center>
        ";
    } else {
        echo "Erro: " . $sqlInsert->error;
    }


?>
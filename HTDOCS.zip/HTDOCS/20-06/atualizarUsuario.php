<?php

    include('conexao.php');

    $id = $_POST['id'];
    $nome = $_POST['nomeTarefa'];
    $data = $_POST['data'];
    $descricao = $_POST['descricao'];


    $sqlInsert = $conn->prepare("UPDATE tarefas SET nome = ?, data = ?,  descricao = ? WHERE id = ?");

    $sqlInsert->bind_param("sssi", $nome, $data, $descricao, $id);

    if ($sqlInsert->execute()) {
        echo "
        <center>
        <b><h1>Tarefa atualizada com<br>Sucesso!</h1></b>
        <a href='lista.php'><button>Voltar</button></a>
        </center>
        ";
    } else {
        echo "Erro: " . $sqlInsert->error;
    }


?>
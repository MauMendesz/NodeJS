<?php

include_once("conexao.php");

if(!$conn ){ 
    echo 'Não foi possível Conectar no Banco de Dados';
exit; }
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <link rel="stylesheet" href="style2.css">
</head>
<body>
  <center>
<div>
<h1>LISTA DE TAREFAS</h1>
<br>
<a href="indexTarefa.php"><button type="button">ADICIONAR TAREFA</button></a>
<br>
<br>
<table width="60%" border="1px">
    <thead>
        <tr>
            <th>Nome</th>
            <th>Data Entrega</th>
            <th>Descrição</th>
        </tr>
    </thead>
    <tbody> 
        <?php
        session_start();
        $sql = "SELECT * FROM tarefas;";
        $query = mysqli_query($conn,$sql);
        while ($row = mysqli_fetch_assoc($query)){ 
            echo '
                <tr>
                    <td>'.$row['nome'].'</td>
                    <td>'.$row['data'].'</td>
                    <td>'.$row['descricao'].'</td>
                    <td>
                    <a href="formulario.php?id='.$row['id'].'"><button  type="button">EDITA</button></a>
                    </td>
                    <td>
                    <a href="delete.php?id='.$row['id'].'"><button  type="button">DELETA</button></a>
                    </td>
                </tr>
            '; }
        ?>
    </tbody>
    </table>
</div>
<br>
<a href="index.php"><button type="button">SAIR</button></a>
</di>
<h2>Logado como: <?php echo $_SESSION['email']; ?> </h2>
</center>
</body>
<?php

  session_start();
  if (isset($_SESSION['login'])) {
    session_destroy();
    header("Location: index.php");
  }
  else {
    echo "<h1>Susuário não autenticado</h1>";
    echo '<a href="index.php">Voltar</a>';
  }

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Login</title>
</head>

<style>
    .form-container {
    display: flex;
    justify-content: center;
    padding: 1%;
}

.form-container form {
    width: '25%';
}

/* Reset styles */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

/* Body styles */
body {
  font-family: Arial, Helvetica, sans-serif;
  background-color: #f5f5f5;
}

/* Form container styles */
.form-container {
  display: flex;
  justify-content: center;
  padding: 1%;
}

/* Form styles */
.form-container form {
  width: 25%;
}

/* Input field styles */
.form-container input {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
}

/* Button styles */
.form-container button {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

/* Button hover styles */
.form-container button:hover {
  opacity: 0.8;
}

/* Header styles */
h1 {
  text-align: center;
}

</style>

<body>

<h1 align='center'>REGISTRAR TAREFA</h1>
<div class="form-container">
    <form action="cadastrarTarefa.php" method="POST">
        <div class="form-container">
        <input type="text" name="nomeTarefa" placeholder="Nome Tarefa" />
        </div>
        <div class="form-container">
       <input type="date" name="data"/>
        
        </div>
        <div class="form-container">
        <input type="text" name="descricao" placeholder="Descricao" size="40"/>
        </div>
        <div class="form-container">
        <button type="submit">Cadastrar</button>
        
        <button href="lista.php">Voltar</button>
        </div>
    </form>
</div>

</body>

</html>
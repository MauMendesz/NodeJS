<?php

    include('conexao.php');


    $nome = $_POST['nomeTarefa'];
    $data = $_POST['data'];
    $descricao = $_POST['descricao'];

    $sqlInsert = $conn->prepare("INSERT INTO tarefas (nome, data, descricao) VALUES (?, ?, ?)");
    $sqlInsert->bind_param('sss', $nome, $data, $descricao);

    if ($sqlInsert->execute()) {
        echo "
        <center>
        <b><h1>Nova Tarefa<br>criada com sucesso!</h1></b>
        <a href='lista.php'><button>Voltar</button></a>
        </center>
        ";
    } else {
        echo "Erro: " . $sqlInsert->error;
    }


?>
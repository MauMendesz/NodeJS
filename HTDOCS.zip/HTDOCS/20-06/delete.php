
<center>
<body>
    <div>
<?php
include_once("conexao.php"); 

$id = $_GET['id'];

$sql = "DELETE FROM tarefas WHERE id = $id";
$execute = mysqli_query($conn,$sql);

if ($execute){
    echo '
    <b><h1>Tarefa excluída Com<br>Sucesso!</h1></b>
'; }
else{
    echo '
    <b><h1>Erro Ao Excluir tarefa</h1></b>
'; } 
?>

<a href="lista.php"><button type="button">LISTA</button></a>
    
</body>
</center>
<?php

$servidor = "localhost";
$user = "root";
$password = "";
$database = "hotel352";

$conn = mysqli_connect($servidor, $user, $password, $database);

if (mysqli_connect_errno()) {
    echo "
    Falha ao conectar no banco de dados
    ";
}else{
    echo "
    Conexão estabelecida com sucesso
    ";
}

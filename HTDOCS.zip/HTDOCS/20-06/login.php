<?php
include ('conexao.php');

session_start();

//Verificação POST vazio
if (empty($_POST) or (empty($_POST['email'])) or (empty($_POST['senha']))) {
  echo "<script> location.href='index.php';</script>";
} else {

  $email = $_POST['email'];
  $senha = $_POST['senha'];
  $senhaEncriptada = password_hash($senha, PASSWORD_BCRYPT);

  $sql = "SELECT senha FROM autenticacao WHERE email = ?;";
  $sqlUsuario = "SELECT email FROM autenticacao WHERE email = ?;";

  $res = $conn->prepare($sql);
  $res->bind_param("s", $email);
  $res->execute();
  $res->bind_result($senhaEncriptadaBanco);
  $res->fetch();
  $res->close();

  $res = $conn->prepare($sqlUsuario);
  $res->bind_param("s", $email);
  $res->execute();
  $res->bind_result($emailBanco);
  $res->fetch();
  $res->close();

  if (!$emailBanco) {
    echo '
    <b><h1>Email inválido</h1></b>
    <br>
    <a href="index.php"><button>Voltar</button></a>
    ';
  } else {
    if (password_verify($senha, $senhaEncriptadaBanco)) {
      session_set_cookie_params(['httponly' => true, 'lifetime' => 86500]);
      session_start();
      $_SESSION['email'] = $_POST['email'];
      header("Location: lista.php");
    } else {
      echo '
      <b><h1>Senha inválida</h1></b>
      <br>
      <a href="index.php"><button>Voltar</button></a>
      ';
    }
  }
}
?>
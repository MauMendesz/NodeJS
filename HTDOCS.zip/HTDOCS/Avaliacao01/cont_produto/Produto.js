const Sequelize = require('sequelize');
const conexao = require('../database/basedados');
const Categoria = require("../cont_categoria/Categoria");

const Produto = conexao.define('produto',{
  id_produto:{
    type:Sequelize.INTEGER,
    autoIncrement: true,
    primaryKey:true
  },

  nome_prod:{
    type:Sequelize.STRING,
    allowNull: false
  },

  body:{
    type:Sequelize.TEXT,
    allowNull: false
     },

  categoria_id: {
    type: Sequelize.INTEGER,
    allowNull: false,
  },
});
  
Categoria.hasMany(Produto, {
  foreignKey: "categoria_id",
});
  
  Produto.belongsTo(Categoria, {
    foreignKey: "categoria_id",
    as: "categoria",
  });     

Produto.sync();
module.exports= Produto;

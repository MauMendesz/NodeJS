const express = require('express');
const router = express.Router();
const bodyParser = require('body-parser');
const Categoria = require('../cont_categoria/Categoria');
const Produto = require('./Produto');

router.use(bodyParser.urlencoded({ extended: true }));

router.get("/verprodutos",(req,res)=>{
    Produto.findAll({
    }).then((produto)=>{
        res.render("produto",{produto})
    })
})

router.get("/novoproduto",(req,res)=>{
    Categoria.findAll().then((produto) => {
        res.render("produtos/cad_produto", { produto })
    })
})

router.get("/controleproduto", (req, res) => {
    Produto.findAll({
        include: [{ model: Categoria, as: 'categoria' }]
    }).then((produto) => {
        res.render("produtos/controle_produtos", { produto });
    })
})

router.post("/deletaproduto",(req,res)=>{
    let id = req.body.id;
    console.log(id)
    Produto.destroy({
        where:{
            id_produto:id
        }
    }).then(()=>{
        res.redirect("/controleproduto")
    })
})

router.post("/salvaproduto", (req, res) => {
    var nome_prod = req.body.nome_prod;
    var body = req.body.body;
    var categoria = req.body.categoria;
    Produto.create({
        nome_prod: nome_prod,
        body: body,
        categoria_id: categoria
    }).then(() => {
        res.redirect("/novoproduto")
    })
})
 
module.exports = router;
const express = require('express');
const app = express();
const conexao = require('./database/basedados');
const router = express.Router();

const Produto = require('./cont_produto/Produto');
const ControleProduto = require('./cont_produto/controleProduto');

const Categoria = require('./cont_categoria/Categoria');
const ControleCategoria = require('./cont_categoria/controleCategoria');

app.set("view engine","ejs");
app.use(express.static('public'));

app.use("/",ControleProduto);
app.use("/",ControleCategoria);

app.get("/",(req,res)=>{
  Produto.findAll().then((produtos)=>{
      res.render("primeiro",{produtos});
   })
})

app.get("/",(req,res)=>{
   Categoria.findAll().then((categorias)=>{
       res.render("categoria",{categorias});
    })
 })

app.get("/ler/:nome_prod",(req,res)=>{
   var nome_prod = req.params.nome_prod;
   Produto.findOne({
       where:{
           nome_prod:nome_prod,
       },
   }).then((produto)=>{
       res.render("lerprod",{produto});
   });
});

conexao.authenticate().then(() =>{
   console.log("CONECTADO COM SUCESSO")
}).catch((erroMsg)=>{
   console.log(erroMsg);
})

app.listen(3000,()=>{
   console.log("SERVIDOR RODANDO...")
});
const express = require('express');
const conexao = require('./database/basedados');
const bodyParser = require('body-parser');
const Email = require ("./tabela/tab_email");

const app = express();

app.set('view engine','ejs');
app.use(bodyParser.urlencoded({ extended: true}));
app.use(express.static("public"));

conexao.authenticate().then(() =>{
    console.log("Conectado com Êxito!!")
 }).catch((err)=>{
    console.log("Erro na conexão");
 })
 
app.get("/", (req, res) => {
    res.render("index", { user: null });
})

 app.post("/pesquisar", async (req, res) => {
    const id = req.body.id;
    const user = await Email.findByPk(id);

 if (user) {
    res.render("index", { user });
 }else{
    res.render("index", { user: "notFound" });
 }
});

 app.listen(3000,()=>{
    console.log("SERVIDOR RODANDO");
 });
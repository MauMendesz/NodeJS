const sequelize = require('sequelize');
const conexao = new sequelize('avalia02_352','root','',{
    host: 'localhost',
    dialect:'mysql',
    define:{
        timestamps:false,
        freezeTableName: true
    }
});
module.exports = conexao;
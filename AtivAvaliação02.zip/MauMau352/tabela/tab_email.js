const Sequelize = require('sequelize');
const conexao = require('../database/basedados');
const Email = conexao.define('tab_email', {
    id_email:{
        type: Sequelize.Sequelize.INTEGER,
        allowNull : false,
        primaryKey : true,
        autoIncrement : true
    },
    nome: {
        type : Sequelize.STRING,
        allowNull : false
    },
    email: {
        type: Sequelize.STRING,
        allowNull : false
    } 
})
Email.sync()
module.exports = Email;